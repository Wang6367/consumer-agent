---
name: 部署方式-ngrok内网穿透
description: '用户无信用卡/京东内网账号,采用本地node+ngrok暴露公网的方式部署Demo'
type: project
---

消费智能体 Demo 通过本地 `node server.js` + ngrok 内网穿透部署到公网。

**Why:** 用户尝试了 Render(需绑信用卡)、Glitch(导入链接跳转异常)均受阻,最终采用 ngrok 方案。用户无京东 ERP 账号,无法用 DevCloud。

**How to apply:** 后续该项目的"部署"需求,优先检查本地 node 服务是否运行,再确认 ngrok 隧道状态;ngrok 免费版重启后网址会变,需重新获取。Node.js 安装在 `C:\Program Files\nodejs\node.exe`,不在系统 PATH 中,需用完整路径调用。